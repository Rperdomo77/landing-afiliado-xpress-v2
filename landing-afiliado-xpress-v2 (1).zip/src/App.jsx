import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '2rem' }}>
      <h1>¿Te gustaría ganar dinero por internet?</h1>
      <p>Descubre el paso a paso de <strong>AFILIADO XPRESS</strong>, el método que me permitió facturar más de $200,000 USD sin tener que crear mi propio producto.</p>
      <button style={{ marginTop: '1rem', padding: '0.5rem 1rem', fontSize: '1rem' }}>Ver la clase ahora</button>
    </div>
  );
}

export default App;